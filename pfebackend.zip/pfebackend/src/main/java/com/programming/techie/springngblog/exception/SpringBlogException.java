package com.programming.techie.springngblog.exception;

public class SpringBlogException extends RuntimeException {
    public SpringBlogException(String message) {
        super(message);
    }
}
