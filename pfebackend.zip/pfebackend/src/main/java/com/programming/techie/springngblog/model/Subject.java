package com.programming.techie.springngblog.model;

public class Subject {

}
